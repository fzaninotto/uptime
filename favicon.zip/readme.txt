Combined favicon (16x16, 32x32 created with ICOBundle from Telegraphics
http://www.telegraphics.com.au/sw/product/ICOBundle

.\icobundl.exe -o favicon.ico .\favicon16x16.ico .\favicon32x32.ico